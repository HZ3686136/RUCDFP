#include <RcppArmadillo.h>
#include <cmath>

using namespace arma;
// [[Rcpp::export]]
arma::mat DFT_2d(arma::mat img){
  // code for fourier transformation
  mat re_mat(img.n_rows,img.n_cols),im_mat(img.n_rows,img.n_cols),ans(img.n_rows,img.n_cols);
  mat output(img.n_rows,img.n_cols);
  double re,im,temp,pi=3.14159265,sum = 0.0;
  double min = DBL_MAX, max = DBL_MIN;
  for(int i = 0;i < img.n_rows;++i)
    for(int j = 0;j < img.n_cols;++j){
      re = 0;
      im = 0;
      
      for (int x = 0;x < img.n_rows;++x)
        for (int y = 0;y < img.n_cols;++y){
          temp = (double)i * x / (double)img.n_rows + (double)j * y /(double)img.n_cols;
          re += img(x,y) * cos(-2 * pi * temp);
          im += img(x,y) * sin(-2 * pi * temp);
        }
      re_mat(i,j) = re;
      im_mat(i,j) = im;
      ans(i,j) = sqrt(re * re + im * im);
      sum += ans(i,j);
      if(min > ans(i,j)){min = ans(i,j);}
      if(max < ans(i,j)){max = ans(i,j);}
    }
  for(int i = 0;i< img.n_rows;++i)
    for(int j = 0;j < img.n_cols;++j){
      output(i,j) = (ans(i,j)-min)/(max-min) + 0;
    }
  return output;
}
// [[Rcpp::export]]
arma::mat fft(arma::vec real,arma::vec imag,int k,int inv)
{
  // real��ʵ��,imag���鲿,k�Ǹ���Ҷ�任�Ĵ��ڳ���,inv�����任������任
  // ����ֵ�Ǿ��� �����һ����ʵ�����ڶ������鲿
  mat result(2,real.n_elem);
  int N = real.n_elem;
  int i,j,k1,k2,m,step,factor_step;
  double temp_real,temp_imag,factor_real,factor_imag;
  
  //����
  vec tempreal(N);
  vec tempimag(N);
  for(i = 0; i < N; i++)
  {
    tempreal[i] = real[i];
    tempimag[i] = imag[i];
  }
  int nInter = 0;
  for(j = 0; j< N; j++)
  {
    nInter = 0;
    for(i = 0; i<k;i++)
    {
      if(j&(1<<i))//�жϵ�iλ�Ƿ�Ϊ1 &�������Ϊ��ĵĲ������ 1&1 = 0 1%0 = 0
      {
        nInter += 1<<(k-i-1);
      }
    }
    real[j] = tempreal[nInter];
    imag[j] = tempimag[nInter];
  }
  //�����㷨
  for(i = 0; i < k; i++)
  {
    step = 1<<(i + 1);
    factor_step = N>>(i + 1);//��ת�����仯�ٶ�
    //��ʼ����ת����
    factor_real = 1.0;
    factor_imag = 0.0;
    
    for(j = 0; j < step/2 ; j++)
    {
      for(k1=j;k1<N;k1+=step)
      {
        k2 = k1+step/2;//�����������������
        temp_real = real[k2]*factor_real-imag[k2]*factor_imag;
        temp_imag = real[k2]*factor_imag+imag[k2]*factor_real;
        real[k2] = real[k1]-temp_real;
        imag[k2] = imag[k1]-temp_imag;
        real[k1] = real[k1]+temp_real;
        imag[k1] = imag[k1]+temp_imag;
      }
      factor_real = inv*cos(-2*PI*(j+1)*factor_step/N);
      factor_imag = inv*sin(-2*PI*(j+1)*factor_step/N);
    }
  }
  if(inv ==-1)
  {
    for(i = 0;i<=N-1;i++)
    {
      real[i]=real[i]/N;
      imag[i]=imag[i]/N;
    }
  }
  for (int i = 0;i<N;i++){
      result(0,i) = real[+i];
    result(1,i) = imag[i];
  }
  return result;
}
